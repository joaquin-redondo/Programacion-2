public class LibrosUNal extends LibrosdeTexto {
    private String facultad;

    public LibrosUNal(String titulo, String autor, String curso, String facultad) {
        super(titulo, autor, curso);
        this.facultad = facultad;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Facultad: " + facultad);
    }
}
