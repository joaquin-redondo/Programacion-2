public class Principal {
    public static void main(String[] args) {
        // Crear instancia de un libro
        Libro libro1 = new Libro("El Principito", "Antoine de Saint-Exupéry");
        libro1.setPrecio(15.99);
        libro1.mostrarInformacion();

        System.out.println();

        // Crear instancia de un libro de texto
        LibrosdeTexto libro2 = new LibrosdeTexto("Cien años de soledad", "Gabriel García Márquez", "Literatura Contemporánea");
        libro2.setPrecio(19.99);
        libro2.mostrarInformacion();

        System.out.println();

        // Crear instancia de un libro de la Universidad Nacional
        LibrosUNal libro3 = new LibrosUNal("Física universitaria", "Sears & Zemansky", "Quinto Semestre", "Facultad de Ciencias Exactas");
        libro3.setPrecio(69.99);
        libro3.mostrarInformacion();

        System.out.println();

        // Crear instancia de una novela
        Novela libro4 = new Novela("La Bella y la Bestia", "Walt Disney Company", "Cuento de hadas");
        libro4.setPrecio(12.99);
        libro4.mostrarInformacion();
    }
}

